# Input Tuner — LeviLaunchroid Input-Fidelity Module

A limitless-options **input tuning** module: deadzone shaping, response
curves, sensitivity, and latency-conscious dispatch for both Bluetooth
gamepad and touchscreen look controls on Minecraft Bedrock (Android),
loaded through LeviLaunchroid.

## Scope, on purpose

This mod reshapes *how faithfully your raw finger/stick motion becomes
an input value*. It does not touch combat outcomes, hit resolution, or
anything server-authoritative — that's decided by the server regardless
of what the client sends, and a client can't legitimately override it.
See `InputLatencyHelper.kt` for the honest breakdown of what
"raw input" and "latency" actually mean on Android.

## What's complete and verified

- **`InputCurve.kt`** — deadzone (inner/outer), response curve exponent,
  sensitivity, and radial vs. per-axis stick shaping. Logic verified
  against 11 test cases (ported to Python and run in this environment
  since no Kotlin toolchain was available here — see `app/src/test/`
  for the equivalent Kotlin/JUnit tests to run in Android Studio).
- **`GamepadSource.kt`** — reads raw axes from Android's public
  `MotionEvent`/`InputDevice` API (SOURCE_JOYSTICK), respects each
  controller's own hardware flat-zone calibration.
- **`TouchLookSource.kt`** — converts raw per-frame touch deltas into a
  shaped look-delta using the same curve engine, normalized by screen
  size.
- **`SettingsStore.kt`** — persists every parameter via SharedPreferences.
- **`SettingsOverlayView.kt`** + **`overlay_input_settings.xml`** — a
  live, draggable settings panel you can pull up over the running game
  (same overlay mechanism as an FPS counter) with sliders for every
  parameter above.
- **`InputLatencyHelper.kt`** — `requestUnbufferedDispatch` and full
  historical-sample extraction, both public Android APIs, to avoid
  wasting input fidelity the OS already gives you.

## What needs your wiring (LeviLaunchroid-specific)

`ModuleEntry.kt` is the seam. I don't have LeviLaunchroid's actual
SO-module loader header/ABI (it's not published anywhere I could fetch
from here), so two things are marked `TODO(loader-specific)`:

1. **The entrypoint symbol/signature their loader calls** when it loads
   your module — check their `docs/` folder or an existing example
   module in the LeviLaunchroid repo/community for the exact hook they
   expect (JNI-style `OnLoad`, a C ABI function they `dlsym()`, etc).
2. **The call that forwards your shaped input onward** so Minecraft
   actually uses your adjusted values instead of its own — this is
   whatever injection point the loader exposes.

Once you have their module template, it should mostly be: call
`ModuleEntry.onModuleLoad()` from their init hook, call
`onGamepadMotion()` / `onTouchMotion()` from wherever they let you tap
input, and forward the returned `StickState`/`LookDelta` using whatever
they expose for that. Everything upstream of that point is complete.

## Building

Open in Android Studio (JDK 17, compileSdk 34, minSdk 28). Run
`app/src/test` for the JUnit tests. Package as whatever module format
LeviLaunchroid's loader expects (likely a `.so` via the NDK if they
want native code, or their own bundling format if Kotlin/Java modules
are supported directly — confirm against their example modules).
