package com.inputtuner.mod

import android.view.MotionEvent
import kotlin.math.abs

/**
 * TouchLookSource
 *
 * Bedrock's touch controls use a drag gesture on the right half of the
 * screen for camera look. This class turns raw per-frame touch deltas
 * into a shaped look-delta using the same curve engine as the gamepad,
 * so touch and controller feel consistent under your chosen settings.
 *
 * This only reshapes *how far the camera turns for a given finger
 * movement* - it does not add auto-aim, does not snap toward entities,
 * and has no knowledge of what's on screen. Pure input-to-output shaping.
 */
class TouchLookSource(private val settings: SettingsStore) {

    private var lastX = 0f
    private var lastY = 0f
    private var tracking = false

    /** Screen diagonal in px, used to normalize deltas across device sizes. */
    var screenDiagonalPx: Float = 2000f

    data class LookDelta(val dx: Float, val dy: Float)

    fun onTouchEvent(event: MotionEvent): LookDelta? {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                lastX = event.x
                lastY = event.y
                tracking = true
                return null
            }
            MotionEvent.ACTION_MOVE -> {
                if (!tracking) return null
                val rawDx = event.x - lastX
                val rawDy = event.y - lastY
                lastX = event.x
                lastY = event.y

                // Normalize raw pixel delta into roughly -1..1 per-frame range
                // before curve shaping, using a configurable max-speed reference
                // so "sensitivity" behaves consistently across screen sizes.
                val norm = (screenDiagonalPx * settings.touchNormFraction).coerceAtLeast(1f)
                val nx = (rawDx / norm).coerceIn(-1f, 1f)
                val ny = (rawDy / norm).coerceIn(-1f, 1f)

                // Same radial-vs-per-axis choice as the sticks: radial=true shapes the
                // drag as one 2D vector (consistent feel in every drag direction),
                // radial=false shapes each axis independently.
                val cfg = settings.touchLookCurve
                val (shapedX, shapedY) = if (cfg.radial) {
                    InputCurve.shapeStick(nx, ny, cfg)
                } else {
                    InputCurve.shapeAxis(nx, cfg) to InputCurve.shapeAxis(ny, cfg)
                }

                return LookDelta(shapedX, shapedY)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP, MotionEvent.ACTION_CANCEL -> {
                tracking = false
                return null
            }
        }
        return null
    }
}
