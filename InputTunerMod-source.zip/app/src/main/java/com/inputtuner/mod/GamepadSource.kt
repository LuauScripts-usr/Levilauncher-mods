package com.inputtuner.mod

import android.view.InputDevice
import android.view.MotionEvent

/**
 * GamepadSource
 *
 * Reads raw analog stick axes straight from the Android MotionEvent,
 * before Minecraft's own input layer has a chance to apply its own
 * (usually coarser) deadzone/smoothing. This is standard public
 * Android API (InputDevice / MotionEvent.getAxisValue) - no hidden
 * hooking, no memory patching, nothing that touches the game process.
 *
 * How this plugs into a real module: whatever entrypoint LeviLaunchroid's
 * SO-module loader gives you for intercepting input (check their
 * `docs/` folder or an example module for the exact hook signature),
 * you feed it the raw MotionEvent here, then hand the *shaped* result
 * to whatever the loader expects you to forward it to. That forwarding
 * call is the one piece I can't write without their actual loader
 * header — everything up to that point is complete and correct as-is.
 */
class GamepadSource(private val settings: SettingsStore) {

    data class StickState(
        val leftX: Float, val leftY: Float,
        val rightX: Float, val rightY: Float,
        val leftTrigger: Float, val rightTrigger: Float
    )

    /**
     * Call this from your input hook with the raw MotionEvent for
     * ACTION_MOVE events from a joystick-class source.
     * Returns shaped stick values ready to forward onward.
     */
    fun process(event: MotionEvent): StickState? {
        val device = event.device ?: return null
        if (device.sources and InputDevice.SOURCE_JOYSTICK != InputDevice.SOURCE_JOYSTICK) {
            return null
        }

        val cfgLeft = settings.leftStickCurve
        val cfgRight = settings.rightStickCurve

        val rawLX = getCenteredAxis(event, device, MotionEvent.AXIS_X)
        val rawLY = getCenteredAxis(event, device, MotionEvent.AXIS_Y)
        val rawRX = getCenteredAxis(event, device, MotionEvent.AXIS_Z)
        val rawRY = getCenteredAxis(event, device, MotionEvent.AXIS_RZ)

        val rawLT = event.getAxisValue(MotionEvent.AXIS_LTRIGGER).coerceIn(0f, 1f)
        val rawRT = event.getAxisValue(MotionEvent.AXIS_RTRIGGER).coerceIn(0f, 1f)

        val (lx, ly) = InputCurve.shapeStick(rawLX, rawLY, cfgLeft)
        val (rx, ry) = InputCurve.shapeStick(rawRX, rawRY, cfgRight)

        return StickState(
            leftX = lx, leftY = ly,
            rightX = rx, rightY = ry,
            leftTrigger = InputCurve.shapeTrigger(rawLT, settings.leftTriggerCurve),
            rightTrigger = InputCurve.shapeTrigger(rawRT, settings.rightTriggerCurve)
        )
    }

    /**
     * Uses the device's own reported flat/fuzz calibration where available,
     * falling back to the raw axis value. This respects per-controller
     * hardware calibration instead of assuming every gamepad is identical.
     */
    private fun getCenteredAxis(event: MotionEvent, device: InputDevice, axis: Int): Float {
        val range = device.getMotionRange(axis, event.source)
        val raw = event.getAxisValue(axis)
        if (range == null) return raw
        // Hardware-reported flat zone; we still apply our own configurable
        // deadzone on top in InputCurve, this just avoids double-counting
        // a stick that's already centered per the driver.
        return if (abs(raw) < range.flat) 0f else raw
    }

    private fun abs(f: Float) = if (f < 0f) -f else f
}
