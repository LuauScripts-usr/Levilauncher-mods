package com.inputtuner.mod

import android.view.MotionEvent
import android.view.View

/**
 * InputLatencyHelper
 *
 * Practical, honest notes on Android input latency - there's no secret
 * "raw pipe" that skips the OS. What actually helps:
 *
 * 1. HISTORICAL BATCHING: Android batches multiple touch samples into
 *    one MotionEvent delivered per frame (via Choreographer). You can
 *    recover the intermediate samples with getHistoricalX/Y instead of
 *    only reading the final coalesced position - this doesn't reduce
 *    latency but DOES recover precision that's otherwise thrown away,
 *    which matters more on high-poll-rate touchscreens/controllers.
 *
 * 2. requestUnbufferedDispatch: tells the OS to bypass the normal
 *    batching-per-frame behavior for a given input device, delivering
 *    events as soon as they arrive rather than waiting for the next
 *    vsync-aligned batch. This is a real, public API
 *    (View.requestUnbufferedDispatch) meant exactly for this use case.
 *
 * 3. Gamepad polling: Android's InputDevice reporting rate is whatever
 *    the Bluetooth/USB controller + OS driver deliver: this mod can't
 *    increase a controller's physical polling rate, only avoid adding
 *    unnecessary software delay on top of it.
 *
 * None of this touches networking, ticks, or server-side hit resolution -
 * it's strictly "don't waste the input fidelity you already have."
 */
object InputLatencyHelper {

    /**
     * Call once when attaching to the surface that receives touch/gamepad
     * input, if the user has lowLatencyMode enabled in settings.
     */
    fun applyUnbufferedDispatch(view: View, settings: SettingsStore) {
        if (!settings.lowLatencyMode) return
        // Requests the system deliver input as it arrives rather than
        // coalescing into one event per frame. Public API, no reflection.
        view.requestUnbufferedDispatch(MotionEvent.TOOL_TYPE_FINGER)
    }

    /**
     * Extracts every historical sample bundled into this MotionEvent
     * instead of just the final position, so fast flicks/swipes aren't
     * silently averaged away. Returns list of (x, y, eventTimeMs).
     */
    fun extractAllSamples(event: MotionEvent, pointerIndex: Int = 0): List<Triple<Float, Float, Long>> {
        val samples = ArrayList<Triple<Float, Float, Long>>(event.historySize + 1)
        for (h in 0 until event.historySize) {
            samples.add(
                Triple(
                    event.getHistoricalX(pointerIndex, h),
                    event.getHistoricalY(pointerIndex, h),
                    event.getHistoricalEventTime(h)
                )
            )
        }
        samples.add(Triple(event.getX(pointerIndex), event.getY(pointerIndex), event.eventTime))
        return samples
    }
}
