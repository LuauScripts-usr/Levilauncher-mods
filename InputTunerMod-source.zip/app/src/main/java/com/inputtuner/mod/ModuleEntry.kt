package com.inputtuner.mod

import android.content.Context
import android.view.MotionEvent
import android.view.WindowManager

/**
 * ModuleEntry
 *
 * This is the seam between "everything this mod does" (input shaping,
 * settings, overlay UI - all complete above) and "how LeviLaunchroid's
 * SO-module loader actually talks to a module" (which I don't have the
 * real header for, since it's not published anywhere I could fetch).
 *
 * Two things depend on their actual loader API and need filling in
 * once you have their module docs/example (check LeviLaunchroid's
 * `docs/` folder or ask in their community for a sample module):
 *
 *   1. The exact entrypoint signature/symbol name their loader calls
 *      when it loads your .so (commonly something like a JNI
 *      `JNI_OnLoad` equivalent, or a C ABI function they dlsym() for).
 *   2. Whatever call forwards your shaped input onward, i.e. how you
 *      hand the game your adjusted stick/touch values instead of the
 *      ones it read natively. Modules that "enhance gameplay" per
 *      their README imply they expose *some* hook for this, but the
 *      shape of it is loader-specific.
 *
 * Everything else - the math, the settings, the overlay - works today
 * as ordinary Android code and doesn't need their loader at all to be
 * correct.
 */
class ModuleEntry(private val context: Context) {

    private lateinit var settings: SettingsStore
    private lateinit var gamepadSource: GamepadSource
    private lateinit var touchSource: TouchLookSource
    private var overlayView: SettingsOverlayView? = null
    private var windowManager: WindowManager? = null

    /** Call this once when the module is loaded. */
    fun onModuleLoad() {
        settings = SettingsStore(context)
        gamepadSource = GamepadSource(settings)
        touchSource = TouchLookSource(settings)
    }

    /**
     * Feed raw gamepad MotionEvents here (from wherever LeviLaunchroid's
     * loader gives you access to input, or from your own InputManager
     * listener if the loader lets you register one directly).
     *
     * Returns the shaped stick state ready to forward to the game.
     * >>> The actual "forward to the game" call is the missing piece <<<
     * — that's whatever API the loader exposes for injecting input,
     * or a shared-memory/JNI bridge into the Minecraft native input path.
     */
    fun onGamepadMotion(event: MotionEvent): GamepadSource.StickState? {
        return gamepadSource.process(event)
        // TODO(loader-specific): forward the returned StickState to
        // Minecraft's input consumer per LeviLaunchroid's actual API.
    }

    fun onTouchMotion(event: MotionEvent): TouchLookSource.LookDelta? {
        return touchSource.onTouchEvent(event)
        // TODO(loader-specific): forward the returned LookDelta the same way.
    }

    /** Toggle the settings overlay - wire this to whatever button/gesture the loader lets you register. */
    fun toggleOverlay() {
        if (overlayView != null) {
            hideOverlay()
        } else {
            showOverlay()
        }
    }

    private fun showOverlay() {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val view = SettingsOverlayView(context, settings)
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.gravity = android.view.Gravity.TOP or android.view.Gravity.START
        wm.addView(view, params)
        overlayView = view
    }

    private fun hideOverlay() {
        overlayView?.let { windowManager?.removeView(it) }
        overlayView = null
    }
}
