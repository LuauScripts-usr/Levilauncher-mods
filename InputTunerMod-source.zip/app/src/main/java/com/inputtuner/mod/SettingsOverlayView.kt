package com.inputtuner.mod

import android.content.Context
import android.view.LayoutInflater
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout

/**
 * SettingsOverlayView
 *
 * A floating, draggable settings panel (added via WindowManager as a
 * TYPE_APPLICATION_OVERLAY, same mechanism FPS counters / recording
 * overlays use) that lets you tune every axis - including both
 * triggers and curve shape/custom points - live while Minecraft is
 * running underneath, plus save/load named presets.
 *
 * Wiring this into LeviLaunchroid: their module loader is the piece
 * that would call show()/hide() on a toggle button/gesture, and it's
 * also what determines whether an SO module is allowed to add a
 * WindowManager overlay in their sandboxed process. Check their
 * example modules for how they expose a settings entrypoint. Everything
 * below is a complete, working overlay view; only that wiring point
 * depends on their loader.
 */
class SettingsOverlayView(context: Context, private val settings: SettingsStore) :
    ConstraintLayout(context) {

    private val curveTypeLabels = CurveType.values().map { it.name.lowercase().replaceFirstChar { c -> c.uppercase() } }

    init {
        LayoutInflater.from(context).inflate(R.layout.overlay_input_settings, this, true)
        bindStickSection("left", settings.leftStickCurve, hasRadial = true) { settings.leftStickCurve = it }
        bindStickSection("right", settings.rightStickCurve, hasRadial = true) { settings.rightStickCurve = it }
        bindStickSection("touch", settings.touchLookCurve, hasRadial = true, showOuterDz = false) { settings.touchLookCurve = it }
        bindTriggerSection("ltrigger", settings.leftTriggerCurve) { settings.leftTriggerCurve = it }
        bindTriggerSection("rtrigger", settings.rightTriggerCurve) { settings.rightTriggerCurve = it }
        bindLatency()
        bindPresets()
    }

    /**
     * Shared binding for anything driven by a full CurveConfig: sticks and touch-look.
     * showOuterDz is false for touch since a drag-delta axis has no meaningful "outer
     * clamp toward a hardware max" the way a physical stick does.
     */
    private fun bindStickSection(
        prefix: String,
        initial: CurveConfig,
        hasRadial: Boolean,
        showOuterDz: Boolean = true,
        onChange: (CurveConfig) -> Unit
    ) {
        var current = initial

        val innerDz = findViewByTag<SeekBar>("${prefix}_inner_dz_seek")
        val outerDz = findViewByTag<SeekBar>("${prefix}_outer_dz_seek")
        val curveTypeSpinner = findViewByTag<Spinner>("${prefix}_curve_type_spinner")
        val expo = findViewByTag<SeekBar>("${prefix}_expo_seek")
        val pointsEdit = findViewByTag<EditText>("${prefix}_points_edit")
        val sens = findViewByTag<SeekBar>("${prefix}_sens_seek")
        val radial = findViewByTag<Switch>("${prefix}_radial_switch")
        val label = findViewByTag<TextView>("${prefix}_label")

        fun push() {
            onChange(current)
            label?.text = "inner=%.2f outer=%.2f type=%s sens=%.2f".format(
                current.innerDeadzone, current.outerDeadzone, current.curveType, current.sensitivity
            )
        }

        innerDz?.progress = (current.innerDeadzone * 100).toInt()
        outerDz?.progress = (current.outerDeadzone * 100).toInt()
        if (!showOuterDz) outerDz?.visibility = android.view.View.GONE
        expo?.progress = (current.responseExponent * 50).toInt()   // 0..~4.0 range
        sens?.progress = (current.sensitivity * 50).toInt()        // 0..~4.0 range
        pointsEdit?.setText(encodePointsForDisplay(current.customPoints))
        if (hasRadial) {
            radial?.isChecked = current.radial
        } else {
            radial?.visibility = android.view.View.GONE
        }
        setupCurveTypeSpinner(curveTypeSpinner, current.curveType) { type ->
            current = current.copy(curveType = type); push()
        }
        push()

        innerDz?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(innerDeadzone = (p / 100f).coerceIn(0f, 0.9f)); push()
        })
        outerDz?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(outerDeadzone = (p / 100f).coerceIn(0.1f, 1f)); push()
        })
        expo?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(responseExponent = (p / 50f).coerceIn(0.1f, 4f)); push()
        })
        sens?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(sensitivity = (p / 50f).coerceIn(0.1f, 4f)); push()
        })
        radial?.setOnCheckedChangeListener { _, checked ->
            current = current.copy(radial = checked); push()
        }
        pointsEdit?.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                current = current.copy(customPoints = parsePointsInput(pointsEdit.text?.toString()))
                push()
            }
        }
    }

    /** Triggers use the same curve math but are single-axis, unidirectional, and have no radial concept. */
    private fun bindTriggerSection(prefix: String, initial: CurveConfig, onChange: (CurveConfig) -> Unit) {
        var current = initial

        val innerDz = findViewByTag<SeekBar>("${prefix}_inner_dz_seek")
        val curveTypeSpinner = findViewByTag<Spinner>("${prefix}_curve_type_spinner")
        val expo = findViewByTag<SeekBar>("${prefix}_expo_seek")
        val label = findViewByTag<TextView>("${prefix}_label")

        fun push() {
            onChange(current)
            label?.text = "deadzone=%.2f type=%s".format(current.innerDeadzone, current.curveType)
        }

        innerDz?.progress = (current.innerDeadzone * 100).toInt()
        expo?.progress = (current.responseExponent * 50).toInt()
        setupCurveTypeSpinner(curveTypeSpinner, current.curveType) { type ->
            current = current.copy(curveType = type); push()
        }
        push()

        innerDz?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(innerDeadzone = (p / 100f).coerceIn(0f, 0.9f)); push()
        })
        expo?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(responseExponent = (p / 50f).coerceIn(0.1f, 4f)); push()
        })
    }

    private fun bindLatency() {
        val latencySwitch = findViewByTag<Switch>("low_latency_switch")
        latencySwitch?.isChecked = settings.lowLatencyMode
        latencySwitch?.setOnCheckedChangeListener { _, checked ->
            settings.lowLatencyMode = checked
        }

        val touchNormSeek = findViewByTag<SeekBar>("touch_norm_seek")
        touchNormSeek?.progress = (settings.touchNormFraction * 1000).toInt()
        touchNormSeek?.setOnSeekBarChangeListener(simpleListener { p ->
            settings.touchNormFraction = (p / 1000f).coerceIn(0.01f, 0.3f)
        })
    }

    private fun bindPresets() {
        val nameEdit = findViewByTag<EditText>("preset_name_edit")
        val spinner = findViewByTag<Spinner>("preset_spinner")
        val saveBtn = findViewByTag<Button>("preset_save_btn")
        val loadBtn = findViewByTag<Button>("preset_load_btn")
        val deleteBtn = findViewByTag<Button>("preset_delete_btn")

        fun refreshSpinner() {
            val names = settings.listPresets()
            spinner?.adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, names)
        }
        refreshSpinner()

        saveBtn?.setOnClickListener {
            val name = nameEdit?.text?.toString()?.trim().orEmpty()
            if (name.isNotEmpty()) {
                settings.savePreset(name)
                refreshSpinner()
            }
        }
        loadBtn?.setOnClickListener {
            val selected = spinner?.selectedItem as? String ?: return@setOnClickListener
            settings.loadPreset(selected)
            // Re-inflate so every slider/spinner/label reflects the loaded preset.
            removeAllViews()
            LayoutInflater.from(context).inflate(R.layout.overlay_input_settings, this, true)
            bindStickSection("left", settings.leftStickCurve, hasRadial = true) { settings.leftStickCurve = it }
            bindStickSection("right", settings.rightStickCurve, hasRadial = true) { settings.rightStickCurve = it }
            bindStickSection("touch", settings.touchLookCurve, hasRadial = true, showOuterDz = false) { settings.touchLookCurve = it }
            bindTriggerSection("ltrigger", settings.leftTriggerCurve) { settings.leftTriggerCurve = it }
            bindTriggerSection("rtrigger", settings.rightTriggerCurve) { settings.rightTriggerCurve = it }
            bindLatency()
            bindPresets()
        }
        deleteBtn?.setOnClickListener {
            val selected = spinner?.selectedItem as? String ?: return@setOnClickListener
            settings.deletePreset(selected)
            refreshSpinner()
        }
    }

    private fun setupCurveTypeSpinner(spinner: Spinner?, current: CurveType, onSelect: (CurveType) -> Unit) {
        spinner ?: return
        spinner.adapter = ArrayAdapter(context, android.R.layout.simple_spinner_dropdown_item, curveTypeLabels)
        spinner.setSelection(current.ordinal, false)
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: android.view.View?, position: Int, id: Long) {
                onSelect(CurveType.values()[position])
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    /** "0.3:0.15,0.7:0.6" -> control points, silently dropping any malformed entries. */
    private fun parsePointsInput(raw: String?): List<CurvePoint> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(",").mapNotNull { pair ->
            val parts = pair.split(":")
            if (parts.size != 2) return@mapNotNull null
            val x = parts[0].trim().toFloatOrNull()?.coerceIn(0f, 1f) ?: return@mapNotNull null
            val y = parts[1].trim().toFloatOrNull()?.coerceIn(0f, 1f) ?: return@mapNotNull null
            CurvePoint(x, y)
        }
    }

    private fun encodePointsForDisplay(points: List<CurvePoint>): String =
        points.joinToString(",") { "%.2f:%.2f".format(it.x, it.y) }

    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> findViewByTag(tag: String): T? = findViewWithTag(tag) as? T
}
