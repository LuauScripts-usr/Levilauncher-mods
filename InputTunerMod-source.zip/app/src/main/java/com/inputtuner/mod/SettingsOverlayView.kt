package com.inputtuner.mod

import android.content.Context
import android.view.LayoutInflater
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout

/**
 * SettingsOverlayView
 *
 * A floating, draggable settings panel (added via WindowManager as a
 * TYPE_APPLICATION_OVERLAY, same mechanism FPS counters / recording
 * overlays use) that lets you tune every axis live while Minecraft is
 * running underneath. Sliders write straight to SettingsStore, and the
 * input sources (GamepadSource / TouchLookSource) read the live
 * CurveConfig on every event, so changes apply instantly - no restart.
 *
 * Wiring this into LeviLaunchroid: their module loader is the piece
 * that would call show()/hide() on a toggle button/gesture, and it's
 * also what determines whether an SO module is allowed to add a
 * WindowManager overlay in their sandboxed process. Check their
 * example modules for how they expose a settings entrypoint. Everything
 * below is a complete, working overlay view; only that wiring point
 * depends on their loader.
 */
class SettingsOverlayView(context: Context, private val settings: SettingsStore) :
    ConstraintLayout(context) {

    init {
        LayoutInflater.from(context).inflate(R.layout.overlay_input_settings, this, true)
        bindStickSection("left", settings.leftStickCurve) { settings.leftStickCurve = it }
        bindStickSection("right", settings.rightStickCurve) { settings.rightStickCurve = it }
        bindStickSection("touch", settings.touchLookCurve) { settings.touchLookCurve = it }
        bindTriggerAndLatency()
    }

    private fun bindStickSection(
        prefix: String,
        initial: CurveConfig,
        onChange: (CurveConfig) -> Unit
    ) {
        var current = initial

        val innerDz = findViewByTag<SeekBar>("${prefix}_inner_dz_seek")
        val outerDz = findViewByTag<SeekBar>("${prefix}_outer_dz_seek")
        val expo = findViewByTag<SeekBar>("${prefix}_expo_seek")
        val sens = findViewByTag<SeekBar>("${prefix}_sens_seek")
        val radial = findViewByTag<Switch>("${prefix}_radial_switch")
        val label = findViewByTag<TextView>("${prefix}_label")

        fun push() {
            onChange(current)
            label?.text = "inner=%.2f outer=%.2f exp=%.2f sens=%.2f".format(
                current.innerDeadzone, current.outerDeadzone,
                current.responseExponent, current.sensitivity
            )
        }

        innerDz?.progress = (current.innerDeadzone * 100).toInt()
        outerDz?.progress = (current.outerDeadzone * 100).toInt()
        expo?.progress = (current.responseExponent * 50).toInt()   // 0..~4.0 range
        sens?.progress = (current.sensitivity * 50).toInt()        // 0..~4.0 range
        radial?.isChecked = current.radial
        push()

        innerDz?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(innerDeadzone = (p / 100f).coerceIn(0f, 0.9f)); push()
        })
        outerDz?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(outerDeadzone = (p / 100f).coerceIn(0.1f, 1f)); push()
        })
        expo?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(responseExponent = (p / 50f).coerceIn(0.1f, 4f)); push()
        })
        sens?.setOnSeekBarChangeListener(simpleListener { p ->
            current = current.copy(sensitivity = (p / 50f).coerceIn(0.1f, 4f)); push()
        })
        radial?.setOnCheckedChangeListener { _, checked ->
            current = current.copy(radial = checked); push()
        }
    }

    private fun bindTriggerAndLatency() {
        val triggerSeek = findViewByTag<SeekBar>("trigger_dz_seek")
        triggerSeek?.progress = (settings.triggerDeadzone * 100).toInt()
        triggerSeek?.setOnSeekBarChangeListener(simpleListener { p ->
            settings.triggerDeadzone = (p / 100f).coerceIn(0f, 0.9f)
        })

        val touchNormSeek = findViewByTag<SeekBar>("touch_norm_seek")
        touchNormSeek?.progress = (settings.touchNormFraction * 1000).toInt()
        touchNormSeek?.setOnSeekBarChangeListener(simpleListener { p ->
            settings.touchNormFraction = (p / 1000f).coerceIn(0.01f, 0.3f)
        })

        val latencySwitch = findViewByTag<Switch>("low_latency_switch")
        latencySwitch?.isChecked = settings.lowLatencyMode
        latencySwitch?.setOnCheckedChangeListener { _, checked ->
            settings.lowLatencyMode = checked
        }
    }

    private fun simpleListener(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
            if (fromUser) onChange(progress)
        }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> findViewByTag(tag: String): T? = findViewWithTag(tag) as? T
}
