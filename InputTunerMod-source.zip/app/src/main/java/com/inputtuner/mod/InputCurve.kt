package com.inputtuner.mod

import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sqrt

/**
 * InputCurve
 *
 * Pure, stateless math for reshaping a single analog axis (-1f..1f).
 * This is the "raw input fidelity" layer: it does NOT know about
 * Minecraft, the game loop, or networking. It just takes a raw axis
 * sample from the OS (gamepad stick / touch-derived look delta) and
 * reshapes it before it's handed to whatever consumes it next.
 *
 * Nothing here changes *what* an action does once it reaches the game
 * or server — only how faithfully/responsively your raw motion maps
 * to the axis value. That's the line this whole mod stays on.
 */
data class CurveConfig(
    /** Values below this (as a fraction of full range, 0..1) are snapped to 0. */
    val innerDeadzone: Float = 0.05f,
    /** Values above this (0..1) are snapped to full magnitude (anti-deadzone / outer clamp). */
    val outerDeadzone: Float = 0.98f,
    /**
     * Response curve exponent.
     * 1.0 = linear.
     * <1.0 = more sensitive near center (easier fine aim).
     * >1.0 = less sensitive near center, ramps up toward the edge (more precision at low speed).
     */
    val responseExponent: Float = 1.0f,
    /** Overall sensitivity multiplier applied after curve shaping. */
    val sensitivity: Float = 1.0f,
    /** If true, treats stick input as radial (x/y shaped together) rather than per-axis. */
    val radial: Boolean = true
)

object InputCurve {

    /**
     * Reshape a single axis value in isolation (used for touch-derived deltas
     * where there's no meaningful 2D radial vector, e.g. drag-to-look on screen).
     */
    fun shapeAxis(raw: Float, cfg: CurveConfig): Float {
        val clamped = raw.coerceIn(-1f, 1f)
        val mag = abs(clamped)
        val shapedMag = shapeMagnitude(mag, cfg)
        return sign(clamped) * shapedMag
    }

    /**
     * Reshape a 2D stick vector (gamepad left/right stick) as a radial
     * deadzone + curve, which feels far better than per-axis deadzones
     * for circular gate sticks — avoids the "square deadzone" problem
     * where diagonals feel different from cardinal directions.
     */
    fun shapeStick(x: Float, y: Float, cfg: CurveConfig): Pair<Float, Float> {
        if (!cfg.radial) {
            return shapeAxis(x, cfg) to shapeAxis(y, cfg)
        }
        val cx = x.coerceIn(-1f, 1f)
        val cy = y.coerceIn(-1f, 1f)
        val mag = sqrt(cx * cx + cy * cy).coerceIn(0f, 1f)
        if (mag < 1e-6f) return 0f to 0f

        val shapedMag = shapeMagnitude(mag, cfg)
        val nx = cx / mag
        val ny = cy / mag
        return (nx * shapedMag) to (ny * shapedMag)
    }

    private fun shapeMagnitude(mag: Float, cfg: CurveConfig): Float {
        if (mag <= cfg.innerDeadzone) return 0f
        if (mag >= cfg.outerDeadzone) return 1f.coerceAtMost(cfg.sensitivity)

        // Rescale so output ramps 0..1 across [innerDeadzone, outerDeadzone]
        val span = (cfg.outerDeadzone - cfg.innerDeadzone).coerceAtLeast(1e-4f)
        val t = ((mag - cfg.innerDeadzone) / span).coerceIn(0f, 1f)

        val curved = t.pow(cfg.responseExponent)
        return (curved * cfg.sensitivity).coerceIn(0f, 4f) // generous ceiling, UI restricts further
    }
}
