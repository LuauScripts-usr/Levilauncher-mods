package com.inputtuner.mod

import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sign
import kotlin.math.sqrt

/**
 * InputCurve
 *
 * Pure, stateless math for reshaping a single analog axis (-1f..1f) or
 * a unidirectional trigger axis (0f..1f). This is the "raw input
 * fidelity" layer: it does NOT know about Minecraft, the game loop, or
 * networking. It just takes a raw axis sample from the OS (gamepad
 * stick / trigger / touch-derived look delta) and reshapes it before
 * it's handed to whatever consumes it next.
 *
 * Nothing here changes *what* an action does once it reaches the game
 * or server - only how faithfully/responsively your raw motion maps
 * to the axis value. That's the line this whole mod stays on.
 */

/** How the normalized [0,1] magnitude between the two deadzones is remapped. */
enum class CurveType {
    /** Straight line: output tracks input 1:1 across the active range. */
    LINEAR,
    /** magnitude^exponent - the original single-knob curve. */
    EXPONENTIAL,
    /** Piecewise-linear interpolation through user-placed (x,y) control points. */
    CUSTOM_POINTS
}

/**
 * A single user-placed control point on a custom curve.
 * x = normalized input position in [0,1] (0 = inner deadzone edge, 1 = outer deadzone edge).
 * y = normalized output magnitude in [0,1].
 */
data class CurvePoint(val x: Float, val y: Float)

data class CurveConfig(
    /** Values below this (as a fraction of full range, 0..1) are snapped to 0. */
    val innerDeadzone: Float = 0.05f,
    /** Values above this (0..1) are snapped to full magnitude (anti-deadzone / outer clamp). */
    val outerDeadzone: Float = 0.98f,
    /** Which shape is used to remap magnitude between the two deadzones. */
    val curveType: CurveType = CurveType.EXPONENTIAL,
    /**
     * Response curve exponent, used only when curveType == EXPONENTIAL.
     * 1.0 = linear.
     * <1.0 = more sensitive near center (easier fine aim).
     * >1.0 = less sensitive near center, ramps up toward the edge (more precision at low speed).
     */
    val responseExponent: Float = 1.0f,
    /**
     * User-placed control points, used only when curveType == CUSTOM_POINTS.
     * Must NOT include the (0,0) and (1,1) endpoints - those are implicit.
     * Points are sorted by x internally; duplicate/out-of-range x values are ignored.
     */
    val customPoints: List<CurvePoint> = emptyList(),
    /** Overall sensitivity multiplier applied after curve shaping. */
    val sensitivity: Float = 1.0f,
    /** If true, treats stick input as radial (x/y shaped together) rather than per-axis. */
    val radial: Boolean = true
)

object InputCurve {

    /**
     * Reshape a single bidirectional axis value in isolation (used for
     * touch-derived deltas where there's no meaningful 2D radial vector,
     * e.g. drag-to-look on screen, or when radial=false for sticks).
     */
    fun shapeAxis(raw: Float, cfg: CurveConfig): Float {
        val clamped = raw.coerceIn(-1f, 1f)
        val mag = abs(clamped)
        val shapedMag = shapeMagnitude(mag, cfg)
        return sign(clamped) * shapedMag
    }

    /**
     * Reshape a 2D stick vector (gamepad left/right stick) as a radial
     * deadzone + curve, which feels far better than per-axis deadzones
     * for circular gate sticks - avoids the "square deadzone" problem
     * where diagonals feel different from cardinal directions.
     */
    fun shapeStick(x: Float, y: Float, cfg: CurveConfig): Pair<Float, Float> {
        if (!cfg.radial) {
            return shapeAxis(x, cfg) to shapeAxis(y, cfg)
        }
        val cx = x.coerceIn(-1f, 1f)
        val cy = y.coerceIn(-1f, 1f)
        val mag = sqrt(cx * cx + cy * cy).coerceIn(0f, 1f)
        if (mag < 1e-6f) return 0f to 0f

        val shapedMag = shapeMagnitude(mag, cfg)
        val nx = cx / mag
        val ny = cy / mag
        return (nx * shapedMag) to (ny * shapedMag)
    }

    /**
     * Reshape a unidirectional trigger axis in [0,1]. Unlike shapeAxis,
     * there's no sign to preserve - the whole [0,1] range is the "magnitude".
     */
    fun shapeTrigger(raw: Float, cfg: CurveConfig): Float {
        val clamped = raw.coerceIn(0f, 1f)
        return shapeMagnitude(clamped, cfg)
    }

    private fun shapeMagnitude(mag: Float, cfg: CurveConfig): Float {
        if (mag <= cfg.innerDeadzone) return 0f
        if (mag >= cfg.outerDeadzone) return cfg.sensitivity.coerceIn(0f, 4f)

        // Rescale so t ramps 0..1 across [innerDeadzone, outerDeadzone]
        val span = (cfg.outerDeadzone - cfg.innerDeadzone).coerceAtLeast(1e-4f)
        val t = ((mag - cfg.innerDeadzone) / span).coerceIn(0f, 1f)

        val curved = when (cfg.curveType) {
            CurveType.LINEAR -> t
            CurveType.EXPONENTIAL -> t.pow(cfg.responseExponent)
            CurveType.CUSTOM_POINTS -> interpolateCustom(t, cfg.customPoints)
        }
        return (curved * cfg.sensitivity).coerceIn(0f, 4f) // generous ceiling, UI restricts further
    }

    /**
     * Piecewise-linear interpolation through (0,0) -> customPoints (sorted, x-deduped,
     * clamped into (0,1) exclusive of the endpoints) -> (1,1). Falls back to identity
     * (linear) if no usable points are provided, so a misconfigured custom curve never
     * throws or divides by zero.
     */
    internal fun interpolateCustom(t: Float, rawPoints: List<CurvePoint>): Float {
        val cleaned = rawPoints
            .filter { it.x > 0f && it.x < 1f }
            .distinctBy { it.x }
            .sortedBy { it.x }

        if (cleaned.isEmpty()) return t

        val points = ArrayList<CurvePoint>(cleaned.size + 2)
        points.add(CurvePoint(0f, 0f))
        points.addAll(cleaned)
        points.add(CurvePoint(1f, 1f))

        for (i in 0 until points.size - 1) {
            val a = points[i]
            val b = points[i + 1]
            if (t >= a.x && t <= b.x) {
                val span = (b.x - a.x).coerceAtLeast(1e-6f)
                val localT = (t - a.x) / span
                return (a.y + (b.y - a.y) * localT).coerceIn(0f, 1f)
            }
        }
        return t.coerceIn(0f, 1f)
    }
}
