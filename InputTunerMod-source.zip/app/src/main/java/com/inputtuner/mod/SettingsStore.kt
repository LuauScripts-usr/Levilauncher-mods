package com.inputtuner.mod

import android.content.Context
import android.content.SharedPreferences

/**
 * SettingsStore
 *
 * Persists all tunable input parameters. Backed by SharedPreferences
 * so settings survive app restarts and can be edited live from the
 * overlay UI (SettingsOverlayView) while Minecraft is running.
 *
 * Also supports named presets: the full set of curves/latency options
 * can be saved under a name and reloaded later, so you can flip between
 * e.g. "Precision" and "Fast" setups without re-tuning every slider.
 */
class SettingsStore(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("input_tuner_prefs", Context.MODE_PRIVATE)

    var leftStickCurve: CurveConfig
        get() = readCurve("left")
        set(v) = writeCurve("left", v)

    var rightStickCurve: CurveConfig
        get() = readCurve("right")
        set(v) = writeCurve("right", v)

    /** Radial defaults to false here (per-axis drag) to preserve prior behavior; toggle on to shape drag as one 2D vector. */
    var touchLookCurve: CurveConfig
        get() = readCurve("touch", defaultRadial = false)
        set(v) = writeCurve("touch", v)

    /** Left analog trigger now gets the full curve treatment, not just a flat deadzone. */
    var leftTriggerCurve: CurveConfig
        get() = readCurve("ltrigger", defaultInner = 0.08f, defaultOuter = 1f)
        set(v) = writeCurve("ltrigger", v)

    /** Right analog trigger, same as above. */
    var rightTriggerCurve: CurveConfig
        get() = readCurve("rtrigger", defaultInner = 0.08f, defaultOuter = 1f)
        set(v) = writeCurve("rtrigger", v)

    /** Fraction of screen diagonal that counts as "full speed" touch drag per frame. */
    var touchNormFraction: Float
        get() = prefs.getFloat("touch_norm_frac", 0.06f)
        set(v) = prefs.edit().putFloat("touch_norm_frac", v).apply()

    /** Reduce input batching where the platform allows it (see InputLatencyHelper). */
    var lowLatencyMode: Boolean
        get() = prefs.getBoolean("low_latency", true)
        set(v) = prefs.edit().putBoolean("low_latency", v).apply()

    // ---------------------------------------------------------------
    // Curve read/write (used for both live sticks/triggers and presets)
    // ---------------------------------------------------------------

    private fun readCurve(
        prefix: String,
        store: SharedPreferences = prefs,
        defaultInner: Float = 0.05f,
        defaultOuter: Float = 0.98f,
        defaultRadial: Boolean = true
    ): CurveConfig = CurveConfig(
        innerDeadzone = store.getFloat("${prefix}_inner_dz", defaultInner),
        outerDeadzone = store.getFloat("${prefix}_outer_dz", defaultOuter),
        curveType = CurveType.values().getOrElse(
            store.getInt("${prefix}_curve_type", CurveType.EXPONENTIAL.ordinal)
        ) { CurveType.EXPONENTIAL },
        responseExponent = store.getFloat("${prefix}_exp", 1.0f),
        customPoints = decodePoints(store.getString("${prefix}_points", null)),
        sensitivity = store.getFloat("${prefix}_sens", 1.0f),
        radial = store.getBoolean("${prefix}_radial", defaultRadial)
    )

    private fun writeCurve(prefix: String, cfg: CurveConfig, store: SharedPreferences = prefs) {
        store.edit()
            .putFloat("${prefix}_inner_dz", cfg.innerDeadzone)
            .putFloat("${prefix}_outer_dz", cfg.outerDeadzone)
            .putInt("${prefix}_curve_type", cfg.curveType.ordinal)
            .putFloat("${prefix}_exp", cfg.responseExponent)
            .putString("${prefix}_points", encodePoints(cfg.customPoints))
            .putFloat("${prefix}_sens", cfg.sensitivity)
            .putBoolean("${prefix}_radial", cfg.radial)
            .apply()
    }

    /** "x1:y1,x2:y2,..." - simple and human-editable if someone wants to hand-craft a curve. */
    private fun encodePoints(points: List<CurvePoint>): String =
        points.joinToString(",") { "${it.x}:${it.y}" }

    private fun decodePoints(raw: String?): List<CurvePoint> {
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split(",").mapNotNull { pair ->
            val parts = pair.split(":")
            if (parts.size != 2) return@mapNotNull null
            val x = parts[0].toFloatOrNull() ?: return@mapNotNull null
            val y = parts[1].toFloatOrNull() ?: return@mapNotNull null
            CurvePoint(x, y)
        }
    }

    // ---------------------------------------------------------------
    // Named presets - a full snapshot of every curve + latency option
    // ---------------------------------------------------------------

    private val presetNamesKey = "preset_names"

    fun listPresets(): List<String> =
        prefs.getStringSet(presetNamesKey, emptySet())?.sorted() ?: emptyList()

    /** Saves the CURRENT live settings under [name], overwriting any existing preset of that name. */
    fun savePreset(name: String) {
        if (name.isBlank()) return
        val presetPrefs = presetStore(name)
        writeCurve("left", leftStickCurve, presetPrefs)
        writeCurve("right", rightStickCurve, presetPrefs)
        writeCurve("touch", touchLookCurve, presetPrefs)
        writeCurve("ltrigger", leftTriggerCurve, presetPrefs)
        writeCurve("rtrigger", rightTriggerCurve, presetPrefs)
        presetPrefs.edit()
            .putFloat("touch_norm_frac", touchNormFraction)
            .putBoolean("low_latency", lowLatencyMode)
            .apply()

        val names = (prefs.getStringSet(presetNamesKey, emptySet()) ?: emptySet()).toMutableSet()
        names.add(name)
        prefs.edit().putStringSet(presetNamesKey, names).apply()
    }

    /** Loads [name] into the live settings. No-op if the preset doesn't exist. */
    fun loadPreset(name: String) {
        if (name !in listPresets()) return
        val presetPrefs = presetStore(name)
        leftStickCurve = readCurve("left", presetPrefs)
        rightStickCurve = readCurve("right", presetPrefs)
        touchLookCurve = readCurve("touch", presetPrefs, defaultRadial = false)
        leftTriggerCurve = readCurve("ltrigger", presetPrefs, defaultInner = 0.08f, defaultOuter = 1f)
        rightTriggerCurve = readCurve("rtrigger", presetPrefs, defaultInner = 0.08f, defaultOuter = 1f)
        touchNormFraction = presetPrefs.getFloat("touch_norm_frac", touchNormFraction)
        lowLatencyMode = presetPrefs.getBoolean("low_latency", lowLatencyMode)
    }

    fun deletePreset(name: String) {
        val names = (prefs.getStringSet(presetNamesKey, emptySet()) ?: emptySet()).toMutableSet()
        if (names.remove(name)) {
            prefs.edit().putStringSet(presetNamesKey, names).apply()
            presetStore(name).edit().clear().apply()
        }
    }

    private fun presetStore(name: String): SharedPreferences =
        context.getSharedPreferences("input_tuner_preset_$name", Context.MODE_PRIVATE)

    fun resetToDefaults() {
        prefs.edit().clear().apply()
    }
}
