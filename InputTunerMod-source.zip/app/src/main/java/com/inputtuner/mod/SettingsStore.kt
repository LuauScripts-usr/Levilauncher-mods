package com.inputtuner.mod

import android.content.Context
import android.content.SharedPreferences

/**
 * SettingsStore
 *
 * Persists all tunable input parameters. Backed by SharedPreferences
 * so settings survive app restarts and can be edited live from the
 * overlay UI (SettingsOverlayView) while Minecraft is running.
 */
class SettingsStore(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("input_tuner_prefs", Context.MODE_PRIVATE)

    var leftStickCurve: CurveConfig
        get() = readCurve("left")
        set(v) = writeCurve("left", v)

    var rightStickCurve: CurveConfig
        get() = readCurve("right")
        set(v) = writeCurve("right", v)

    var touchLookCurve: CurveConfig
        get() = readCurve("touch")
        set(v) = writeCurve("touch", v)

    var triggerDeadzone: Float
        get() = prefs.getFloat("trigger_dz", 0.08f)
        set(v) = prefs.edit().putFloat("trigger_dz", v).apply()

    /** Fraction of screen diagonal that counts as "full speed" touch drag per frame. */
    var touchNormFraction: Float
        get() = prefs.getFloat("touch_norm_frac", 0.06f)
        set(v) = prefs.edit().putFloat("touch_norm_frac", v).apply()

    /** Reduce input batching where the platform allows it (see InputLatencyHelper). */
    var lowLatencyMode: Boolean
        get() = prefs.getBoolean("low_latency", true)
        set(v) = prefs.edit().putBoolean("low_latency", v).apply()

    private fun readCurve(prefix: String): CurveConfig = CurveConfig(
        innerDeadzone = prefs.getFloat("${prefix}_inner_dz", 0.05f),
        outerDeadzone = prefs.getFloat("${prefix}_outer_dz", 0.98f),
        responseExponent = prefs.getFloat("${prefix}_exp", 1.0f),
        sensitivity = prefs.getFloat("${prefix}_sens", 1.0f),
        radial = prefs.getBoolean("${prefix}_radial", true)
    )

    private fun writeCurve(prefix: String, cfg: CurveConfig) {
        prefs.edit()
            .putFloat("${prefix}_inner_dz", cfg.innerDeadzone)
            .putFloat("${prefix}_outer_dz", cfg.outerDeadzone)
            .putFloat("${prefix}_exp", cfg.responseExponent)
            .putFloat("${prefix}_sens", cfg.sensitivity)
            .putBoolean("${prefix}_radial", cfg.radial)
            .apply()
    }

    fun resetToDefaults() {
        prefs.edit().clear().apply()
    }
}
