package com.inputtuner.mod

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.sqrt

class InputCurveTest {

    @Test
    fun `values inside inner deadzone snap to zero`() {
        val cfg = CurveConfig(innerDeadzone = 0.1f)
        assertEquals(0f, InputCurve.shapeAxis(0.05f, cfg), 1e-4f)
        assertEquals(0f, InputCurve.shapeAxis(-0.05f, cfg), 1e-4f)
    }

    @Test
    fun `values above outer deadzone clamp to full sensitivity`() {
        val cfg = CurveConfig(outerDeadzone = 0.9f, sensitivity = 1.0f)
        assertEquals(1f, InputCurve.shapeAxis(0.95f, cfg), 1e-4f)
        assertEquals(-1f, InputCurve.shapeAxis(-0.95f, cfg), 1e-4f)
    }

    @Test
    fun `linear curve is identity between deadzones at sensitivity 1`() {
        val cfg = CurveConfig(innerDeadzone = 0f, outerDeadzone = 1f, responseExponent = 1f, sensitivity = 1f)
        assertEquals(0.5f, InputCurve.shapeAxis(0.5f, cfg), 1e-3f)
    }

    @Test
    fun `sensitivity multiplier scales output`() {
        val cfg = CurveConfig(innerDeadzone = 0f, outerDeadzone = 1f, responseExponent = 1f, sensitivity = 2f)
        assertEquals(1.0f, InputCurve.shapeAxis(0.5f, cfg), 1e-3f)
    }

    @Test
    fun `exponent greater than 1 reduces sensitivity near center`() {
        val cfg = CurveConfig(innerDeadzone = 0f, outerDeadzone = 1f, responseExponent = 2f, sensitivity = 1f)
        val shaped = InputCurve.shapeAxis(0.5f, cfg)
        assertTrue("expected sub-linear response near center, got $shaped", shaped < 0.5f)
    }

    @Test
    fun `radial deadzone preserves direction for diagonal stick input`() {
        val cfg = CurveConfig(innerDeadzone = 0f, outerDeadzone = 1f, responseExponent = 1f, sensitivity = 1f, radial = true)
        val (x, y) = InputCurve.shapeStick(0.5f, 0.5f, cfg)
        // direction should be preserved (45 degrees), magnitude shaped
        assertEquals(x, y, 1e-4f)
        val mag = sqrt(x * x + y * y)
        val expectedMag = sqrt(0.5f * 0.5f + 0.5f * 0.5f) // ~0.707, within outer deadzone range
        assertEquals(expectedMag.coerceAtMost(1f), mag, 1e-2f)
    }

    @Test
    fun `radial deadzone zeroes out small diagonal noise same as cardinal`() {
        // A per-axis deadzone would let a tiny diagonal through on both axes;
        // radial deadzone should zero it based on combined magnitude.
        val cfg = CurveConfig(innerDeadzone = 0.2f, radial = true)
        val (x, y) = InputCurve.shapeStick(0.05f, 0.05f, cfg) // magnitude ~0.07, below 0.2 deadzone
        assertEquals(0f, x, 1e-4f)
        assertEquals(0f, y, 1e-4f)
    }

    @Test
    fun `trigger-style single axis never exceeds sensitivity ceiling in practice`() {
        val cfg = CurveConfig(sensitivity = 1.5f, innerDeadzone = 0f, outerDeadzone = 1f, responseExponent = 1f)
        val shaped = InputCurve.shapeAxis(1f, cfg)
        assertTrue(shaped <= 1.5f + 1e-3f)
    }

    @Test
    fun `LINEAR curve type ignores exponent and is identity in range`() {
        val cfg = CurveConfig(
            innerDeadzone = 0f, outerDeadzone = 1f, sensitivity = 1f,
            curveType = CurveType.LINEAR, responseExponent = 3f // should be ignored
        )
        assertEquals(0.5f, InputCurve.shapeAxis(0.5f, cfg), 1e-3f)
        assertEquals(0.25f, InputCurve.shapeAxis(0.25f, cfg), 1e-3f)
    }

    @Test
    fun `CUSTOM_POINTS with no points falls back to identity`() {
        val cfg = CurveConfig(
            innerDeadzone = 0f, outerDeadzone = 1f, sensitivity = 1f,
            curveType = CurveType.CUSTOM_POINTS, customPoints = emptyList()
        )
        assertEquals(0.4f, InputCurve.shapeAxis(0.4f, cfg), 1e-3f)
    }

    @Test
    fun `CUSTOM_POINTS interpolates through a single control point`() {
        // A point at (0.5, 0.9) should pull the midpoint output up sharply,
        // while still hitting exactly 0.9 at t=0.5 and endpoints at 0 and 1.
        val cfg = CurveConfig(
            innerDeadzone = 0f, outerDeadzone = 1f, sensitivity = 1f,
            curveType = CurveType.CUSTOM_POINTS,
            customPoints = listOf(CurvePoint(0.5f, 0.9f))
        )
        assertEquals(0.9f, InputCurve.shapeAxis(0.5f, cfg), 1e-3f)
        assertEquals(0f, InputCurve.shapeAxis(0f, cfg), 1e-3f)
        assertEquals(1f, InputCurve.shapeAxis(1f, cfg), 1e-3f)
        // Halfway between (0, 0) and (0.5, 0.9) should be halfway in y too (linear segment).
        assertEquals(0.45f, InputCurve.shapeAxis(0.25f, cfg), 1e-3f)
    }

    @Test
    fun `CUSTOM_POINTS ignores out-of-range and duplicate x values`() {
        val cfg = CurveConfig(
            innerDeadzone = 0f, outerDeadzone = 1f, sensitivity = 1f,
            curveType = CurveType.CUSTOM_POINTS,
            customPoints = listOf(
                CurvePoint(-0.2f, 0.9f), // out of range, dropped
                CurvePoint(1.5f, 0.1f),  // out of range, dropped
                CurvePoint(0.5f, 0.3f),
                CurvePoint(0.5f, 0.8f)   // duplicate x, first one wins (distinctBy)
            )
        )
        assertEquals(0.3f, InputCurve.shapeAxis(0.5f, cfg), 1e-3f)
    }

    @Test
    fun `shapeTrigger treats input as unsigned 0 to 1 with deadzone and curve`() {
        val cfg = CurveConfig(innerDeadzone = 0.1f, outerDeadzone = 1f, curveType = CurveType.LINEAR, sensitivity = 1f)
        assertEquals(0f, InputCurve.shapeTrigger(0.05f, cfg), 1e-4f)
        assertEquals(1f, InputCurve.shapeTrigger(1f, cfg), 1e-4f)
        // Negative input should not produce a negative trigger value (clamped to 0..1 first).
        assertEquals(0f, InputCurve.shapeTrigger(-0.5f, cfg), 1e-4f)
    }
}
